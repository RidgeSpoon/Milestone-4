﻿namespace Mile_Stone_Inventory_Moving_List
{
    partial class TheList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.retButt3 = new System.Windows.Forms.Button();
            this.detLab1 = new System.Windows.Forms.Label();
            this.detLab2 = new System.Windows.Forms.Label();
            this.detLab3 = new System.Windows.Forms.Label();
            this.detLab4 = new System.Windows.Forms.Label();
            this.detLab5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // retButt3
            // 
            this.retButt3.Location = new System.Drawing.Point(12, 220);
            this.retButt3.Name = "retButt3";
            this.retButt3.Size = new System.Drawing.Size(222, 23);
            this.retButt3.TabIndex = 1;
            this.retButt3.Text = "Return";
            this.retButt3.UseVisualStyleBackColor = true;
            this.retButt3.Click += new System.EventHandler(this.retButt3_Click);
            // 
            // detLab1
            // 
            this.detLab1.AutoSize = true;
            this.detLab1.Location = new System.Drawing.Point(12, 51);
            this.detLab1.Name = "detLab1";
            this.detLab1.Size = new System.Drawing.Size(38, 15);
            this.detLab1.TabIndex = 3;
            this.detLab1.Text = "label1";
            // 
            // detLab2
            // 
            this.detLab2.AutoSize = true;
            this.detLab2.Location = new System.Drawing.Point(12, 86);
            this.detLab2.Name = "detLab2";
            this.detLab2.Size = new System.Drawing.Size(38, 15);
            this.detLab2.TabIndex = 4;
            this.detLab2.Text = "label1";
            // 
            // detLab3
            // 
            this.detLab3.AutoSize = true;
            this.detLab3.Location = new System.Drawing.Point(12, 124);
            this.detLab3.Name = "detLab3";
            this.detLab3.Size = new System.Drawing.Size(38, 15);
            this.detLab3.TabIndex = 5;
            this.detLab3.Text = "label1";
            // 
            // detLab4
            // 
            this.detLab4.AutoSize = true;
            this.detLab4.Location = new System.Drawing.Point(12, 157);
            this.detLab4.Name = "detLab4";
            this.detLab4.Size = new System.Drawing.Size(38, 15);
            this.detLab4.TabIndex = 6;
            this.detLab4.Text = "label1";
            // 
            // detLab5
            // 
            this.detLab5.AutoSize = true;
            this.detLab5.Location = new System.Drawing.Point(12, 188);
            this.detLab5.Name = "detLab5";
            this.detLab5.Size = new System.Drawing.Size(38, 15);
            this.detLab5.TabIndex = 7;
            this.detLab5.Text = "label1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(168, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Name----Ethnicity----Charges";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, -2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Rooms And Occupants";
            // 
            // TheList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 256);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.detLab5);
            this.Controls.Add(this.detLab4);
            this.Controls.Add(this.detLab3);
            this.Controls.Add(this.detLab2);
            this.Controls.Add(this.detLab1);
            this.Controls.Add(this.retButt3);
            this.Name = "TheList";
            this.Text = "TheList";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button retButt3;
        private Button refButt;
        private Label detLab1;
        private Label detLab2;
        private Label inmLab1;
        private Label inmLab2;
        private Label inmLab3;
        private Label detLab3;
        private Label detLab4;
        private Label detLab5;
        private Label label4;
        private Label label1;
    }
}